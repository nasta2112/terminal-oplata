package com.example.posterminal

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.nfc.NfcAdapter
import android.nfc.tech.IsoDep
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.ContentTransform
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.BiasAlignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) { if (c is Activity) return c; c = c.baseContext }
    return null
}

// ---------- Палитра с фото ----------
val Indigo = Color(0xFF212842)   // Midnight Indigo
val Royal = Color(0xFF162660)    // Royal Blue
val Cream = Color(0xFFF0E7D5)    // Vanilla Cream
val Beige = Color(0xFFF1E4D1)    // Warm Beige
val Powder = Color(0xFFD0E6FD)   // Powder Blue
val Birch = Color(0xFFDEC4C9)    // Birch Blossom
val Hearth = Color(0xFF977272)   // Muted Hearth
val Wood = Color(0xFF594E4C)     // Woodsmoke Shadow
val Forest = Color(0xFF181717)   // Midnight Forest
val Lime = Birch                 // главный акцент (кнопки, плитки)
val Ink = Indigo                 // тёмный текст на светлом
val Paper = Beige
val Card = Color(0x26D0E6FD)
val KeyBg = Color(0x2EF0E7D5)
val White = Cream
val Soft = Color(0xB3F0E7D5)
val Err = Color(0xFFC48B8B)
fun Modifier.glow(): Modifier = drawBehind {
    drawRect(Indigo)
    drawRect(Brush.radialGradient(
        listOf(Color(0xFF2E4BB5).copy(alpha = .85f), Royal.copy(alpha = .7f), Color.Transparent),
        center = Offset(size.width * .5f, size.height * .82f), radius = size.width * 1.3f))
    drawRect(Brush.radialGradient(
        listOf(Birch.copy(alpha = .22f), Color.Transparent),
        center = Offset(size.width * .95f, size.height * .04f), radius = size.width * .9f))
}

val METH = mapOf("nfc" to "Карта (NFC)", "qr" to "QR СБП", "p2p" to "P2P перевод")
fun glyph(m: String) = when (m) { "qr" -> "▦"; "nfc" -> "))"; else -> "⇄" }
val PPSE = byteArrayOf(0x00, 0xA4.toByte(), 0x04, 0x00, 0x0E) + "2PAY.SYS.DDF01".toByteArray() + byteArrayOf(0x00)

// ---------- Модель ----------
data class Tx(
    val id: Long, val time: Long, val type: String, val amt: Long, val method: String,
    val who: String, val rrn: String, val auth: String, val ok: Boolean,
    val why: String = "", val refunded: Boolean = false
)
data class Session(val step: String, val method: String = "", val pin: String = "", val res: Tx? = null, val card: String = "", val scheme: String = "")

fun fmt(c: Long): String = "%,.2f".format(Locale("ru", "RU"), c / 100.0) + " ₽"
fun rnd(n: Int) = (1..n).joinToString("") { Random.nextInt(10).toString() }
fun whenStr(t: Long): String = SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale("ru")).format(Date(t))

class PosVM : ViewModel() {
    var mode by mutableStateOf("pay")
    var amt by mutableStateOf("")
    var phone by mutableStateOf("")
    var flow by mutableStateOf<Session?>(null)
    var view by mutableStateOf<Tx?>(null)
    val tx = mutableStateListOf<Tx>()
    val amount: Long get() = amt.toLongOrNull() ?: 0L

    fun mainKey(k: String) {
        when (k) {
            "C" -> amt = amt.dropLast(1)
            "00" -> if (amt.isNotEmpty() && amt.length <= 6) amt += "00"
            else -> if (amt.length < 8) amt = (amt + k).trimStart('0')
        }
    }
    fun startPay() {
        if (amount <= 0) return
        flow = if (mode == "p2p") Session("phone", "p2p") else Session("tap", "nfc")
    }
    fun pickQr() { flow = Session("tap", "qr") }
    fun afterQr() { val f = flow ?: return; if (f.step == "tap" && f.method == "qr") flow = f.copy(step = "proc") }

    // Вызывается, когда реальная (или демо) карта приложена
    fun cardTapped(scheme: String, last4: String) {
        val f = flow ?: return
        if (f.step != "tap" || f.method != "nfc") return
        val g = f.copy(card = "**** $last4", scheme = scheme)
        flow = if (amount >= 300000) g.copy(step = "pin") else g.copy(step = "proc")
    }

    fun flowKey(k: String) {
        val f = flow ?: return
        if (f.step == "phone") {
            when (k) {
                "C" -> phone = phone.dropLast(1)
                "OK" -> if (phone.length == 10) flow = f.copy(step = "pin", pin = "")
                else -> if (phone.length < 10) phone += k
            }
        } else if (f.step == "pin") {
            when (k) {
                "C" -> flow = f.copy(pin = f.pin.dropLast(1))
                "OK" -> if (f.pin.length == 4) flow = f.copy(step = "proc")
                else -> if (f.pin.length < 4) flow = f.copy(pin = f.pin + k)
            }
        }
    }
    fun complete() {
        val f = flow ?: return
        var ok = true
        var why = ""
        if (f.pin == "0000") { ok = false; why = "Неверный PIN" }
        else if (Random.nextDouble() < 0.06) { ok = false; why = "Недостаточно средств" }
        val who = when (f.method) {
            "p2p" -> "+7 *** *** ${phone.substring(6, 8)}-${phone.substring(8, 10)}"
            "qr" -> "СБП клиент"
            else -> "${f.scheme} ${f.card}"
        }
        val t = Tx(System.currentTimeMillis(), System.currentTimeMillis(), if (f.method == "p2p") "p2p" else "sale",
            amount, f.method, who, rnd(12), if (ok) rnd(6) else "—", ok, why)
        tx.add(0, t)
        flow = Session("done", f.method, res = t)
    }
    fun closeFlow() {
        if (flow?.step == "done") { amt = ""; phone = "" }
        flow = null
    }
    fun refund(t: Tx) {
        val i = tx.indexOfFirst { it.id == t.id }
        if (i < 0) return
        tx[i] = t.copy(refunded = true)
        val r = Tx(System.currentTimeMillis(), System.currentTimeMillis(), "refund", t.amt, t.method, t.who,
            rnd(12), rnd(6), true, "Возврат по ${t.rrn.takeLast(6)}")
        tx.add(0, r)
        view = r
    }
}

class MainActivity : ComponentActivity() {
    private val vm: PosVM by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent { App(vm) }
    }
}

// Отступ сверху: под статус-баром и вырезом камеры (чёлкой) + 20dp
const val TOP_GAP = 20
@Composable
fun Modifier.safeTop(): Modifier =
    this.windowInsetsPadding(WindowInsets.statusBars.union(WindowInsets.displayCutout)).padding(top = TOP_GAP.dp)

// ---------- Общие элементы ----------
@Composable
fun Cta(text: String, color: Color = Lime, fg: Color = Ink, enabled: Boolean = true, onClick: () -> Unit) = Button(
    onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().height(58.dp), shape = RoundedCornerShape(20.dp),
    colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = fg, disabledContainerColor = KeyBg, disabledContentColor = Soft.copy(alpha = .4f))
) { AnimatedContent(text, label = "cta") { t -> Text(t, fontSize = 17.sp, fontWeight = FontWeight.SemiBold) } }

@Composable
fun Keypad(confirm: Boolean = false, onKey: (String) -> Unit) {
    val haptic = LocalHapticFeedback.current
    val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"),
        if (confirm) listOf("C", "0", "OK") else listOf("00", "0", "C"))
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { k ->
                    Button(
                        onClick = { haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove); onKey(k) },
                        modifier = Modifier.weight(1f).height(56.dp), shape = RoundedCornerShape(18.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (k == "OK") Lime else KeyBg, contentColor = if (k == "OK") Ink else White)
                    ) { Text(when (k) { "C" -> "⌫"; "OK" -> "✓"; else -> k }, fontSize = 22.sp, fontWeight = FontWeight.SemiBold) }
                }
            }
        }
    }
}

@Composable
fun QrArt(dim: Dp, dark: Color, light: Color) {
    Canvas(Modifier.size(dim).background(light, RoundedCornerShape(12.dp)).padding(dim / 14)) {
        val n = 21; val c = size.width / n
        for (i in 0 until n) for (j in 0 until n) {
            val finder = (i < 7 && j < 7) || (i >= n - 7 && j < 7) || (i < 7 && j >= n - 7)
            val on = if (finder) {
                val x = if (i >= n - 7) i - (n - 7) else i
                val y = if (j >= n - 7) j - (n - 7) else j
                x == 0 || x == 6 || y == 0 || y == 6 || (x in 2..4 && y in 2..4)
            } else (i * 7 + j * 13 + i * j * 3) % 5 < 2
            if (on) drawRect(dark, Offset(i * c, j * c), Size(c + .5f, c + .5f))
        }
    }
}

@Composable
fun Pulse() {
    val t = rememberInfiniteTransition(label = "pulse")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1600, easing = LinearEasing)), label = "a")
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "rot")
    Canvas(Modifier.size(230.dp)) {
        val r = size.minDimension / 2
        for (i in 0..2) {
            val p = (a + i / 3f) % 1f
            drawCircle(Powder.copy(alpha = (1 - p) * .55f), radius = r * (.3f + .7f * p), style = Stroke(5f))
        }
        drawCircle(Powder, radius = r * .28f)
        drawCircle(Ink, radius = r * .1f)
        drawArc(Powder, rot, 110f, false, Offset(size.width / 2 - r * .5f, size.height / 2 - r * .5f), Size(r, r), style = Stroke(10f, cap = StrokeCap.Round))
        drawArc(Powder.copy(alpha = .35f), rot + 180f, 60f, false, Offset(size.width / 2 - r * .5f, size.height / 2 - r * .5f), Size(r, r), style = Stroke(10f, cap = StrokeCap.Round))
    }
}

@Composable
fun TopWaves(modifier: Modifier) {
    val t = rememberInfiniteTransition(label = "waves")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "a")
    Canvas(modifier.fillMaxWidth().height(380.dp)) {
        val c = Offset(size.width / 2, -30f)
        drawCircle(Brush.radialGradient(listOf(Powder.copy(alpha = .5f), Color.Transparent), center = c, radius = 300f), radius = 300f, center = c)
        for (i in 0..3) {
            val p = (a + i / 4f) % 1f
            drawCircle(Powder.copy(alpha = (1 - p) * .65f), radius = 70f + p * size.width * .9f, center = c, style = Stroke(3f + (1 - p) * 6f))
        }
        drawArc(Powder, 20f, 140f, false, Offset(c.x - 120f, c.y - 120f), Size(240f, 240f), style = Stroke(6f, cap = StrokeCap.Round))
    }
}

@Composable
fun Burst(modifier: Modifier) {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) { p.animateTo(1f, tween(1300, easing = FastOutSlowInEasing)) }
    Canvas(modifier) {
        val c = Offset(size.width / 2, size.height / 2)
        val maxR = Size(size.width, size.height).maxDimension
        for (i in 0..2) {
            val q = (p.value * (1.2f - i * .15f)).coerceIn(0f, 1f)
            drawCircle(Powder.copy(alpha = (1 - q) * .8f), radius = q * maxR * .9f, center = c, style = Stroke(10f - i * 3f))
        }
    }
}

@Composable
fun CheckAnim(ok: Boolean) {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) { p.animateTo(1f, tween(1000, easing = FastOutSlowInEasing)) }
    Canvas(Modifier.size(150.dp)) {
        val r = size.minDimension / 2
        drawCircle((if (ok) Powder else Err).copy(alpha = .25f), radius = r * (.7f + .3f * p.value))
        drawCircle(if (ok) Powder else Err, radius = r * .7f * (p.value * 2f).coerceAtMost(1f))
        val k = ((p.value - .4f) / .6f).coerceIn(0f, 1f)
        val w = size.width; val h = size.height
        if (ok) {
            val a = Offset(w * .32f, h * .52f); val b = Offset(w * .46f, h * .65f); val c = Offset(w * .70f, h * .38f)
            drawLine(Ink, a, a + (b - a) * (k * 2).coerceAtMost(1f), 14f, StrokeCap.Round)
            if (k > .5f) drawLine(Ink, b, b + (c - b) * ((k - .5f) * 2), 14f, StrokeCap.Round)
        } else {
            val a = Offset(w * .36f, h * .36f); val b = Offset(w * .64f, h * .64f)
            drawLine(White, a, a + (b - a) * k, 14f, StrokeCap.Round)
            drawLine(White, Offset(b.x, a.y), Offset(b.x, a.y) + (Offset(a.x, b.y) - Offset(b.x, a.y)) * k, 14f, StrokeCap.Round)
        }
    }
}

@Composable
fun ReceiptView(t: Tx) {
    @Composable fun row(a: String, b: String, bold: Boolean = false) = Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(a, color = Ink, fontFamily = FontFamily.Monospace, fontSize = 13.sp, fontWeight = if (bold) FontWeight.Bold else null)
        Text(b, color = Ink, fontFamily = FontFamily.Monospace, fontSize = 13.sp, fontWeight = if (bold) FontWeight.Bold else null)
    }
    @Composable fun center(s: String, bold: Boolean = false) = Text(s, color = Ink, fontFamily = FontFamily.Monospace, fontSize = 13.sp,
        fontWeight = if (bold) FontWeight.Bold else null, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    Column(Modifier.fillMaxWidth().background(Paper, RoundedCornerShape(16.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        center("ИП «ТОЧКА ПРОДАЖ»", true)
        center("Терминал № 00417")
        center("- - - - - - - - - - - - - - -")
        center(when (t.type) { "sale" -> "ОПЛАТА"; "p2p" -> "P2P ПЕРЕВОД"; else -> "ВОЗВРАТ" }, true)
        row("Дата", whenStr(t.time))
        row("Способ", METH[t.method] ?: "")
        row(if (t.type == "p2p") "Получатель" else "Карта", t.who)
        row("RRN", t.rrn)
        row("Код авт.", t.auth)
        center("- - - - - - - - - - - - - - -")
        row("ИТОГО", (if (t.type == "refund") "-" else "") + fmt(t.amt), true)
        center(if (t.ok) "ОДОБРЕНО" else "ОТКАЗ", true)
        if (t.why.isNotEmpty()) center(t.why)
        center("Эмуляция. Не платёжный документ.")
    }
}

// ---------- Приложение ----------
@Composable
fun App(vm: PosVM) {
    var tab by remember { mutableStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme(background = Indigo, surface = Card, primary = Lime, onPrimary = Ink)) {
        Box(Modifier.fillMaxSize().glow()) {
            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets(0.dp, 0.dp, 0.dp, 0.dp),
                bottomBar = {
                    NavigationBar(containerColor = Royal) {
                        listOf("Касса" to "₽", "Операции" to "≡", "Смена" to "Σ").forEachIndexed { i, (label, icon) ->
                            NavigationBarItem(
                                selected = tab == i, onClick = { tab = i },
                                icon = { Text(icon, fontSize = 20.sp) }, label = { Text(label) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Ink, selectedTextColor = White, indicatorColor = Lime,
                                    unselectedIconColor = Soft, unselectedTextColor = Soft)
                            )
                        }
                    }
                }
            ) { pad ->
                Box(Modifier.padding(pad).safeTop().padding(16.dp).fillMaxSize()) {
                    when (tab) { 0 -> Kassa(vm); 1 -> History(vm); else -> Shift(vm) }
                }
            }
            vm.flow?.let { f ->
                BackHandler { vm.closeFlow() }
                FlowScreen(vm, f)
            }
            vm.view?.let { ViewScreen(vm, it) }
        }
    }
}

@Composable
fun Kassa(vm: PosVM) {
    val p2p = vm.mode == "p2p"
    val bias by animateFloatAsState(if (p2p) 1f else -1f, tween(380, easing = FastOutSlowInEasing), label = "bias")
    val cardTint by animateColorAsState(if (p2p) Birch.copy(alpha = .2f) else Card, tween(380), label = "tint")
    val slide: AnimatedContentTransitionScope<String>.() -> ContentTransform = {
        val dir = if (targetState == "p2p") 1 else -1
        (slideInHorizontally(tween(380)) { it / 3 * dir } + fadeIn(tween(380))) togetherWith
            (slideOutHorizontally(tween(380)) { -it / 3 * dir } + fadeOut(tween(200)))
    }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("касса", color = Soft, fontSize = 14.sp)
            Box(Modifier.fillMaxWidth().background(KeyBg, RoundedCornerShape(50)).padding(4.dp)) {
                Box(Modifier.fillMaxWidth(.5f).height(40.dp).align(BiasAlignment(bias, 0f)).background(Lime, RoundedCornerShape(50)))
                Row(Modifier.fillMaxWidth()) {
                    listOf("pay" to "Оплата картой", "p2p" to "P2P перевод").forEach { (m, l) ->
                        val on = vm.mode == m
                        val c by animateColorAsState(if (on) Ink else White, tween(300), label = "chip")
                        Box(Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(50)).clickable { vm.mode = m }, contentAlignment = Alignment.Center) {
                            Text(l, color = c, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
        Column(Modifier.fillMaxWidth().background(cardTint, RoundedCornerShape(28.dp)).padding(22.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            AnimatedContent(vm.mode, transitionSpec = slide, label = "label") { m ->
                Text(if (m == "p2p") "сумма перевода" else "сумма к оплате", color = Soft, fontSize = 14.sp)
            }
            Text(fmt(vm.amount), color = White, fontSize = 42.sp, fontWeight = FontWeight.Bold, maxLines = 1)
        }
        Keypad(onKey = vm::mainKey)
        Cta(if (p2p) "Перевести" else "Принять оплату", enabled = vm.amount > 0) { vm.startPay() }
    }
}

@Composable
fun FlowScreen(vm: PosVM, f: Session) {
    val ctx = LocalContext.current
    val act = ctx.findActivity()
    val adapter = remember { NfcAdapter.getDefaultAdapter(ctx) }
    var tick by remember { mutableStateOf(0) }
    var showRc by remember { mutableStateOf(false) }
    var nfcLog by remember { mutableStateOf("") }
    val haptic = LocalHapticFeedback.current

    // Обновляем статус NFC при возвращении из настроек
    DisposableEffect(Unit) {
        val owner = act as? ComponentActivity
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner?.lifecycle?.addObserver(obs)
        onDispose { owner?.lifecycle?.removeObserver(obs) }
    }
    val nfcState = if (tick >= 0) (if (adapter == null) 0 else if (!adapter.isEnabled) 1 else 2) else 0

    // Реальное чтение карты: включаем reader mode только пока ждём карту
    DisposableEffect(f.step, f.method, tick) {
        val a = adapter
        if (act != null && a != null && a.isEnabled && f.step == "tap" && f.method == "nfc") {
            val extras = Bundle()
            extras.putInt(NfcAdapter.EXTRA_READER_PRESENCE_CHECK_DELAY, 250)
            a.enableReaderMode(act, { tag ->
                val techs = tag.techList.joinToString { it.substringAfterLast('.') }
                act.runOnUiThread { nfcLog = "карта обнаружена ($techs)" }
                var scheme = "Карта"
                try {
                    val iso = IsoDep.get(tag)
                    if (iso != null) {
                        iso.timeout = 1200
                        iso.connect()
                        try {
                            val h = iso.transceive(PPSE).joinToString("") { "%02X".format(it) }
                            scheme = when {
                                h.contains("A0000006581010") || h.contains("A0000006582010") -> "МИР"
                                h.contains("A00000000310") -> "Visa"
                                h.contains("A00000000410") -> "Mastercard"
                                else -> "Карта"
                            }
                        } finally { try { iso.close() } catch (e: Exception) { } }
                    }
                } catch (e: Exception) { }
                val uid = tag.id.joinToString("") { "%02X".format(it) }
                val last4 = (uid.hashCode() and 0x7fffffff).toString().padStart(4, '0').takeLast(4)
                act.runOnUiThread { vm.cardTapped(scheme, last4) }
            }, NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or NfcAdapter.FLAG_READER_NFC_F or
                NfcAdapter.FLAG_READER_NFC_V or NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK, extras)
        }
        onDispose { if (act != null && a != null) try { a.disableReaderMode(act) } catch (e: Exception) { } }
    }

    LaunchedEffect(f.step, f.method) {
        when {
            f.step == "tap" && f.method == "qr" -> { delay(3500); vm.afterQr() }
            f.step == "proc" -> { delay(2600); vm.complete() }
            f.step == "done" -> haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        }
    }

    Box(Modifier.fillMaxSize().glow().pointerInput(Unit) {}) {
    if (f.step == "tap" && f.method == "nfc") TopWaves(Modifier.align(Alignment.TopCenter))
    if (f.step == "done" && f.res?.ok == true) Burst(Modifier.fillMaxSize())
    Column(Modifier.fillMaxSize().safeTop().navigationBarsPadding().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            Column(Modifier.weight(1f)) {
                Text(if (f.method == "p2p") "перевод" else "оплата", color = Soft, fontSize = 14.sp)
                Text(fmt(vm.amount), color = White, fontSize = 34.sp, fontWeight = FontWeight.Medium)
            }
            Text("✕", color = White, fontSize = 22.sp, modifier = Modifier.clickable { vm.closeFlow() }.padding(8.dp))
        }
        Column(
            Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically)
        ) {
            val msg: @Composable (String) -> Unit = { Text(it, color = White, fontSize = 18.sp, textAlign = TextAlign.Center) }
            when (f.step) {
                "tap" -> if (f.method == "qr") {
                    QrArt(230.dp, Ink, White)
                    msg("отсканируйте QR-код\nв приложении банка")
                } else {
                    val t = rememberInfiniteTransition(label = "arrow")
                    val y by t.animateFloat(0f, 1f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "y")
                    Text("↑", color = Lime, fontSize = 64.sp, fontWeight = FontWeight.Bold, modifier = Modifier.offset(y = (-14f * y).dp))
                    msg("приложите карту\nк задней панели телефона")
                    Text(when (nfcState) {
                        0 -> "На этом устройстве нет NFC. Нажмите лаймовую плитку для демо."
                        1 -> "NFC выключен"
                        else -> "NFC готов. Приложите карту к верхней части задней панели (антенна), снимите чехол"
                    }, color = Soft, fontSize = 13.sp, textAlign = TextAlign.Center)
                    if (nfcLog.isNotEmpty()) Text(nfcLog, color = Birch, fontSize = 13.sp)
                    if (nfcState == 1) TextButton(onClick = { ctx.startActivity(Intent(Settings.ACTION_NFC_SETTINGS)) }) { Text("Включить NFC", color = Lime) }
                }
                "phone" -> {
                    Text("телефон получателя", color = Soft)
                    Text("+7 " + vm.phone.ifEmpty { "__________" }, color = White, fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
                    Keypad(true, vm::flowKey)
                }
                "pin" -> {
                    Text(if (f.method == "p2p") "PIN отправителя" else "${f.scheme} ${f.card} · введите PIN", color = Soft)
                    Text("●".repeat(f.pin.length) + "○".repeat(4 - f.pin.length), color = Lime, fontSize = 36.sp, letterSpacing = 8.sp)
                    Keypad(true, vm::flowKey)
                }
                "proc" -> {
                    Pulse()
                    msg("обрабатываем платёж…")
                    if (f.card.isNotEmpty()) Text("${f.scheme} ${f.card}", color = Soft, fontSize = 14.sp)
                }
                "done" -> f.res?.let { t ->
                    if (showRc) ReceiptView(t) else {
                        CheckAnim(t.ok)
                        Text(if (!t.ok) "отказ" else if (t.type == "p2p") "перевод выполнен" else "оплачено", color = White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                        Text(if (!t.ok) t.why else "Спасибо за покупку!", color = Soft, fontSize = 15.sp)
                    }
                }
            }
        }
        if (f.step == "tap" && f.method == "nfc") {
            Row(Modifier.fillMaxWidth().height(150.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.weight(1f).fillMaxHeight().background(Card, RoundedCornerShape(24.dp)).clickable { vm.pickQr() }.padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    QrArt(64.dp, White, Color.Transparent)
                    Text("отсканируйте\nQR-код", color = White, fontSize = 14.sp)
                }
                Column(Modifier.weight(1f).fillMaxHeight().background(Lime, RoundedCornerShape(24.dp)).clickable { vm.cardTapped("МИР", rnd(4)) }.padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    Text("›", color = Ink, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text("нажмите для\nдемо-оплаты", color = Ink, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        if (f.step == "done") {
            TextButton(onClick = { showRc = !showRc }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text(if (showRc) "скрыть чек" else "показать чек", color = Lime)
            }
            Cta("Понятно") { vm.closeFlow() }
        }
        }
    }
}

@Composable
fun ViewScreen(vm: PosVM, t: Tx) {
    BackHandler { vm.view = null }
    val cur = vm.tx.firstOrNull { it.id == t.id } ?: t
    Column(Modifier.fillMaxSize().glow().pointerInput(Unit) {}.safeTop().navigationBarsPadding().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) { ReceiptView(cur) }
        if (cur.ok && cur.type != "refund" && !cur.refunded) Cta("Сделать возврат", KeyBg, White) { vm.refund(cur) }
        Cta("Понятно") { vm.view = null }
    }
}

@Composable
fun History(vm: PosVM) {
    Column {
        Text("Операции", color = White, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))
        if (vm.tx.isEmpty()) Text("Пока пусто. Проведите первую оплату на вкладке «Касса».", color = Soft, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 30.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.tx) { t ->
                Row(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(20.dp)).clickable { vm.view = t }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(if (t.ok) Lime else Err, CircleShape), contentAlignment = Alignment.Center) { Text(glyph(t.method), color = Ink, fontWeight = FontWeight.Bold) }
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        val name = when (t.type) { "sale" -> "Оплата"; "p2p" -> "P2P"; else -> "Возврат" }
                        val st = if (t.refunded) "возвращён" else if (t.ok) "успешно" else "отказ"
                        Text("$name · $st", color = White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        Text("${whenStr(t.time)} · ${METH[t.method]}", color = Soft, fontSize = 12.sp)
                    }
                    Text((if (t.type == "refund") "−" else "") + fmt(t.amt), color = if (t.ok) White else Err, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
fun Shift(vm: PosVM) {
    val ok = vm.tx.filter { it.ok }
    fun sum(type: String) = ok.filter { it.type == type }.sumOf { it.amt }
    val sales = sum("sale"); val p2p = sum("p2p"); val rf = sum("refund")
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Итоги смены", color = White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Column(Modifier.fillMaxWidth().background(Lime, RoundedCornerShape(28.dp)).padding(22.dp)) {
            Text("итого в кассе", color = Ink.copy(alpha = .7f), fontSize = 14.sp)
            Text(fmt(sales + p2p - rf), color = Ink, fontSize = 38.sp, fontWeight = FontWeight.Bold)
        }
        listOf("Оплаты" to sales, "P2P переводы" to p2p, "Возвраты" to rf).forEach { (l, v) ->
            Row(Modifier.fillMaxWidth().background(Card, RoundedCornerShape(18.dp)).padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(l, color = White, fontSize = 16.sp)
                Text(fmt(v), color = Lime, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(4.dp))
        Cta("Закрыть смену (очистить)", KeyBg, White) { vm.tx.clear() }
    }
}
